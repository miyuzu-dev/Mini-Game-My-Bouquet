# 🌷 My Bouquet

**A little kindness grows here.**

My Bouquet là game React phong cách pixel pastel: người chơi trả lời 5 câu hỏi tự suy ngẫm bằng tiếng Việt, nhận một bó hoa, trang trí góc nhỏ và mở lá thư dành cho tổ hợp câu trả lời của mình.

Project tách riêng **frontend React** và **backend Node.js + Express**, có REST API Hello World theo yêu cầu HW4. Kiến trúc triển khai dự kiến: frontend trên Vercel, backend trên Render. Repository đã có cấu hình deploy; chưa cung cấp URL triển khai thực tế.

![Sơ đồ kiến trúc My Bouquet](docs/architecture.svg)

## Tính năng

- 5 câu hỏi × 5 mức trả lời, ánh xạ đến 25 loại hoa; tổng cộng **3.125 tổ hợp**.
- Tên hoa, ý nghĩa và toàn bộ 3.125 lá thư lấy từ Excel; thư được tra cứu nguyên văn, không sinh bằng AI khi chơi.
- Sắp xếp vị trí 5 bông hoa bằng kéo/chạm hoặc nút mũi tên.
- 10 dáng bình, 5 màu bình và 5 kiểu trang trí.
- 5 họa tiết tường, 10 màu tường, 5 kiểu cửa sổ, 6 đồ vật đặt cạnh bình.
- Phong thư có hiệu ứng xuất hiện và mở thư.
- Chăm hoa mỗi ngày qua 3 câu Có/Không: tưới nước, đón nắng, tỉa lá. Cả hai câu trả lời đều thực hiện chăm sóc, với lời nhắn khác nhau.
- Sổ hoa hiển thị hoa đã mở khóa và hoa chưa tìm thấy.
- Màn đầu có ngôi nhà pixel, mây, khói, suối và bé gái tóc bob vàng chào người chơi.
- Nhạc nền, âm thanh tương tác được tạo bằng Web Audio; đồ họa được vẽ bằng SVG/CSS/code.
- Tiến trình và tùy chỉnh lưu bằng LocalStorage, riêng cho từng trình duyệt và tên miền.

Đây là trò chơi tự suy ngẫm, không phải công cụ đánh giá hay chẩn đoán sức khỏe tâm lý.

## 1. Sơ đồ kiến trúc tổng thể

```mermaid
flowchart TB
    Player[Người chơi] --> UI
    subgraph Frontend[Frontend React · triển khai trên Vercel]
        UI[Giao diện và điều hướng]
        Reflection[5 câu hỏi và ánh xạ hoa]
        Art[Đồ họa pixel SVG và CSS]
        Custom[Sắp hoa và trang trí]
        Care[Chăm hoa và Sổ hoa]
        Audio[Nhạc và hiệu ứng Web Audio]
        Client[API client · fetchLetter]
        UI --> Reflection
        UI --> Custom
        UI --> Care
        UI --> Art
        UI --> Audio
        UI --> Client
    end
    UI <-->|Đọc và lưu tiến trình| Local[(LocalStorage của trình duyệt)]
    Client -->|GET /api/letters/:combination| API
    subgraph Backend[Backend Node.js + Express · triển khai trên Render]
        API[CORS và định tuyến API]
        Validate[Kiểm tra 5 chữ số từ 1 đến 5]
        Lookup[Tra cứu thư theo tổ hợp]
        Data[(JSON · 25 hoa và 3.125 thư)]
        Hello[GET /api/hello · Hello World]
        API --> Validate --> Lookup
        Data --> Lookup
        API --> Hello
    end
    Lookup -->|JSON chứa thư nguyên văn| Client
    classDef pink fill:#ffe3ed,stroke:#986280,color:#49394c;
    classDef mint fill:#e0efd4,stroke:#81956d,color:#354b3a;
    classDef blue fill:#deedf7,stroke:#7795b0,color:#354358;
    class UI,Reflection,Art,Custom,Care,Audio,Client pink;
    class API,Validate,Lookup,Hello mint;
    class Data,Local blue;
```

Frontend dùng bản dữ liệu 25 hoa đi kèm để hiển thị ngay; **lá thư được lấy từ backend**. API `/api/flowers` cũng có sẵn nhưng giao diện hiện tại chưa gọi endpoint này. Backend đọc JSON vào bộ nhớ khi khởi động; không dùng database và không lưu tiến trình người chơi.

## 2. Sơ đồ luồng chơi

```mermaid
flowchart TD
    Enter[Mở game] --> Load{Có tiến trình đã lưu?}
    Load -->|Chưa có| Intro[Ngôi nhà · chưa có bình hoa]
    Load -->|Đang chơi dở| Resume[Tiếp tục câu hỏi hoặc sắp hoa]
    Load -->|Đã hoàn thành| Home[Góc hoa của bạn]
    Intro --> Start[Bắt đầu]
    Start --> Questions[Trả lời 5 câu · mỗi câu 5 mức]
    Questions --> Flowers[Nhận và mở khóa 5 hoa]
    Flowers --> Arrange[Sắp xếp bó hoa]
    Resume --> Questions
    Resume --> Arrange
    Arrange --> HasVase{Đã có bình từ lần trước?}
    HasVase -->|Chưa| Vase[Chọn dáng, màu, trang trí bình]
    Vase --> Corner[Chọn tường, cửa sổ và đồ vật]
    Corner --> Request[Lấy thư từ backend]
    HasVase -->|Có| Request
    Request --> Ready{Lấy thư thành công?}
    Ready -->|Không| Retry[Hiện thông báo và nút thử lại]
    Retry --> Request
    Ready -->|Có| Envelope[Phong thư xuất hiện]
    Envelope --> Open[Chạm mở thư và đọc]
    Open --> Save[Lưu hoàn thành vào LocalStorage]
    Save --> Home
    Home --> Daily[Chăm hoa mỗi ngày]
    Home --> Journal[Sổ hoa]
    Home --> Edit[Trang trí lại bình và phòng]
    Home --> New[Tạo bó mới · giữ bình và bộ sưu tập]
    New --> Questions
    Daily --> Home
    Journal --> Home
    Edit --> Home
```

Sổ hoa và chuông chăm hoa xuất hiện trên thanh công cụ sau khi bắt đầu chơi. Mở lại game khi còn câu trả lời dở sẽ tiếp tục ở câu tiếp theo; nếu đã đủ 5 câu nhưng chưa hoàn thành thì quay lại bước sắp hoa.

## 3. Sơ đồ dữ liệu và API lấy thư

```mermaid
sequenceDiagram
    actor P as Người chơi
    participant R as React
    participant E as Express API
    participant J as JSON trong bộ nhớ
    participant L as LocalStorage
    P->>R: Hoàn thành 5 câu và trang trí
    R->>R: Chuyển lựa chọn 0–4 thành khóa 1–5
    Note over R: Ví dụ khóa 12345 = bó số 195
    R->>E: GET /api/letters/12345
    E->>E: Xử lý CORS và kiểm tra mã tổ hợp
    alt Mã hợp lệ
        E->>J: Tra cứu khóa 12345
        J-->>E: Bản ghi thư gốc
        E-->>R: 200 JSON
        R->>R: Kiểm tra ID và nội dung thư
        R-->>P: Hiển thị phong thư
        P->>R: Mở thư
        R->>L: Lưu trạng thái đã hoàn thành
        R-->>P: Hiển thị nội dung thư
    else Mã không hợp lệ
        E-->>R: 400 JSON error
        R-->>P: Thông báo và nút thử lại
    end
```

CORS cho phép trình duyệt đọc phản hồi từ các origin đã khai báo; nó không thay thế xác thực. Các API chỉ cung cấp nội dung game, không yêu cầu tài khoản.

## 4. Sơ đồ chăm hoa hàng ngày

```mermaid
flowchart LR
    Bell[Chuông nhắc trong game] --> Date{Đã chăm hôm nay?}
    Date -->|Chưa| Form[3 câu hỏi Có / Không]
    Date -->|Rồi| Thanks[Thông báo đã chăm · có thể xem lại]
    Form --> Water[Câu 1 · Tưới nước]
    Form --> Sun[Câu 2 · Đón nắng]
    Form --> Trim[Câu 3 · Tỉa lá]
    Water --> Message[Hiệu ứng và lời nhắn theo câu trả lời]
    Sun --> Message
    Trim --> Message
    Message --> Complete{Đã trả lời đủ 3 câu?}
    Complete -->|Chưa| Form
    Complete -->|Đủ| Save[Lưu ngày và câu trả lời bằng LocalStorage]
    Save --> Home[Về góc hoa · tắt chấm nhắc hôm nay]
```

Ngày chăm tính theo lịch trên thiết bị. Chuông là nhắc nhở **trong game**, không phải thông báo hệ thống khi đã đóng trang. Không có hình phạt hoặc hoa chết nếu bỏ qua một ngày.

## Công nghệ và cấu trúc thư mục

| Thành phần | Công nghệ / trách nhiệm |
|---|---|
| Frontend | React 19, Vite 6, JavaScript |
| Đồ họa | SVG, CSS, sprite pixel tạo bằng code |
| Âm thanh | Web Audio API, không tải bản ghi bên ngoài |
| Backend | Node.js 22+, Express 5, CORS |
| Dữ liệu | JSON chuyển từ workbook Excel |
| Tiến trình | LocalStorage |
| Deploy dự kiến | Vercel frontend, Render backend |
| Kiểm thử | Node.js test runner |

```text
my-bouquet-hw4/
├── frontend/
│   ├── src/
│   │   ├── App.jsx             # Luồng chơi và trạng thái
│   │   ├── api.js              # Gọi HTTP lấy thư
│   │   ├── game-data.js        # Câu hỏi, ánh xạ, kiểm tra dữ liệu
│   │   ├── flowers.json        # 25 hoa dùng ở frontend
│   │   ├── sprites.js          # Hình pixel của 25 hoa
│   │   ├── pixel-art.jsx       # Phòng, bình, icon, logo
│   │   ├── Cottage.jsx         # Ngôi nhà và bé gái chào cửa
│   │   ├── audio.js            # Nhạc nền và hiệu ứng âm thanh
│   │   ├── pixel.css           # Giao diện và chuyển động
│   │   └── game.test.js        # Kiểm tra ánh xạ và tiến trình
│   ├── vite.config.js
│   ├── .env.example
│   └── package.json / package-lock.json
├── backend/
│   ├── src/
│   │   ├── app.js              # REST API, CORS, validation
│   │   ├── server.js           # PORT và khởi động server
│   │   └── app.test.js         # Kiểm thử HTTP và API client
│   ├── data/                  # Hoa, 3.125 thư và thông tin nguồn
│   ├── .env.example
│   └── package.json / package-lock.json
├── docs/
│   ├── architecture.svg       # Sơ đồ tổng thể dạng ảnh vector
│   └── DEPLOYMENT.md          # Hướng dẫn deploy chi tiết
├── render.yaml
└── README.md
```

## REST API

| Method | Endpoint | Kết quả |
|---|---|---|
| GET | `/` | Hello World và thông tin project |
| GET | `/api/hello` | `{"message":"Hello World"}` — endpoint HW4 |
| GET | `/api/health` | `{"status":"ok"}` |
| GET | `/api/flowers` | Danh sách 25 hoa |
| GET | `/api/letters/:combination` | Thư theo mã 5 chữ số từ 1 đến 5 |

Ví dụ: `/api/letters/12345` trả bản ghi bó số 195 với `id`, `levels`, `flowerIds`, `bouquet`, `text`. Mã sai trả HTTP 400; endpoint không tồn tại trả HTTP 404.

## Chạy để phát triển

Cần Node.js 22+ và npm. Mở thư mục gốc project bằng VS Code.

Terminal 1:

```sh
cd backend
npm ci
npm start
```

Terminal 2, bắt đầu từ thư mục gốc:

```sh
cd frontend
npm ci
npm run dev
```

Game: http://127.0.0.1:5175. Hello World: http://127.0.0.1:3001/api/hello.

Không cần `.env` khi dùng cấu hình phát triển mặc định: Vite proxy `/api` đến backend cổng 3001. Nhạc chỉ phát khi trình duyệt cho phép; thao tác đầu tiên sẽ thử khởi động âm thanh.

## Deploy và biến môi trường

Xem **[hướng dẫn deploy Render + Vercel](docs/DEPLOYMENT.md)** cho từng bước, ảnh cần chụp khi nộp và cách xử lý lỗi.

| Dịch vụ | Root Directory | Build | Start / Output |
|---|---|---|---|
| Render backend | `backend` | `npm ci` | `npm start` |
| Vercel frontend | `frontend` | `npm run build` | `dist` |

- Frontend: `VITE_API_URL=https://TEN-BACKEND.onrender.com`.
- Backend: `FRONTEND_ORIGINS=https://TEN-FRONTEND.vercel.app`.
- Render cung cấp `PORT`; server bind `0.0.0.0`.
- Thay các tên mẫu bằng URL thật. Thay `VITE_API_URL` cần build/deploy frontend lại.
- Sau deploy, cập nhật README này với URL frontend và URL `/api/hello` thật để người xem kiểm tra.

## Kiểm thử

Chạy trên bản project đầy đủ để test có thể đối chiếu dữ liệu giữa frontend và backend:

```sh
cd backend
npm test
cd ../frontend
npm test
npm run build
```

Các kiểm tra gồm API Hello World, tra thư qua HTTP, CORS, lỗi đầu vào, hủy yêu cầu, toàn bộ 3.125 tổ hợp, 25 sprite khác nhau, dữ liệu lưu và ngày chăm. Bản mã đã vượt qua 6 kiểm thử cùng bước build frontend; việc deploy thực tế cần được xác minh riêng.

## Dữ liệu và giới hạn hiện tại

Nguồn nội dung: `flower_game_3125_most_tender_letters_spaced.xlsx`. Tệp `backend/data/source.json` lưu thông tin nguồn và checksum. Tên, ý nghĩa và thư giữ nguyên nội dung được nhập; câu 4 và câu 5 dùng cách diễn đạt phù hợp nhóm “Mất định hướng” và “Khó chăm sóc bản thân” trong dữ liệu.

Game lưu một bó hiện tại; tạo bó mới giữ bình, góc phòng và các hoa đã mở khóa. Chưa có tài khoản, đồng bộ máy chủ, lịch sử nhiều bó, vẽ tay lên bình hoặc xuất ảnh. Backend cung cấp thư đọc từ JSON; không ghi dữ liệu người chơi vào tệp trên Render.

## Chuẩn bị push GitHub

1. Mở đúng thư mục `my-bouquet-hw4` bằng VS Code.
2. Commit `frontend`, `backend`, `docs`, `README.md`, `render.yaml` và `.gitignore`.
3. Giữ cả hai `package-lock.json` và các tệp JSON trong `backend/data`.
4. Không commit `node_modules`, `dist` hay `.env`; `.gitignore` đã cấu hình.
5. GitHub sẽ hiển thị ảnh SVG và các sơ đồ Mermaid ngay trong README.
