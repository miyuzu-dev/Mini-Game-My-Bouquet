# My Bouquet — HW4: React frontend + Node.js / Express backend

Bản tách frontend/backend từ game pixel đã được duyệt. Giữ nguyên đồ họa, nhạc, nhân vật chào cửa và 3.125 thư Excel.

## Đối chiếu đề trong ảnh

- HW4: tạo RESTful API Hello World bằng Node.js + Express và deploy trên Render.
- Đã có `GET /api/hello` trả JSON `{"message":"Hello World"}`. `GET /` cũng trả Hello World.
- Frontend React liên hệ với backend qua HTTP: khi mở thư, gọi `GET /api/letters/12345`.
- HW3 trong cùng ảnh yêu cầu React trên Vercel. Hướng dẫn dưới dùng Vercel cho frontend, Render cho backend.
- Code đã chuẩn bị để deploy; chưa được đưa lên tài khoản Render/Vercel của bạn. Chỉ hoàn tất điều kiện “deployed” sau khi có URL Render chạy thật.
- Không có yêu cầu CRUD, database hay tài khoản trong ảnh. Tiến trình vẫn lưu trên trình duyệt, không đồng bộ giữa máy hoặc tên miền.

## Cấu trúc

```text
my-bouquet-hw4/
  frontend/
    src/                 React, đồ họa, âm thanh, trạng thái game
    package.json
    package-lock.json
    vite.config.js       proxy API khi phát triển
    .env.example
  backend/
    src/app.js           Express routes, CORS, kiểm tra đầu vào
    src/server.js        nhận PORT của Render, bind 0.0.0.0
    src/app.test.js      kiểm thử HTTP API
    data/                25 hoa + nguyên văn 3.125 thư
    package.json
    package-lock.json
    .env.example
  render.yaml            cấu hình Blueprint tùy chọn
  README.md
```

Mở toàn bộ thư mục `my-bouquet-hw4` bằng VS Code. Hai thư mục có dependencies độc lập, không cần workspace npm.

## 1. Đưa mã nguồn lên GitHub

1. Giải nén ZIP. Tạo repository GitHub mới, ví dụ `my-bouquet-hw4`.
2. Trong VS Code mở thư mục `my-bouquet-hw4`, chọn Source Control → Initialize Repository, commit rồi Publish Branch; hoặc upload nội dung thư mục vào repository.
3. Ở trang đầu repository phải thấy trực tiếp `frontend`, `backend`, `render.yaml`, `README.md`.
4. Không upload `node_modules`, `dist`, `.env`; `.gitignore` đã loại chúng. Phải có cả hai `package-lock.json` và thư mục `backend/data`.

## 2. Deploy backend lên Render — phần bắt buộc HW4

Trong Render Dashboard chọn **New → Web Service**, kết nối GitHub và chọn repository vừa tạo. Chọn đúng nhánh đã có code.

| Trường | Giá trị cho project này |
|---|---|
| Name | Tên bạn muốn, ví dụ my-bouquet-api |
| Language / Runtime | Node |
| Root Directory | `backend` |
| Build Command | `npm ci` |
| Start Command | `npm start` |
| Health Check Path | `/api/health` |

Thêm biến môi trường:

```text
NODE_ENV=production
FRONTEND_ORIGINS=http://localhost:5175,http://127.0.0.1:5175
```

Chọn gói dịch vụ phù hợp (Free nếu tài khoản có lựa chọn đó), rồi **Create Web Service**. Không cần tự đặt PORT; server đã dùng `process.env.PORT` và `0.0.0.0`. Làm theo [tài liệu Express của Render](https://render.com/docs/deploy-node-express-app) và [quy định cổng Web Service](https://render.com/docs/web-services).

Khi trạng thái Live, sao chép URL thực tế Render cấp, ví dụ `https://TEN-THAT-CUA-BAN.onrender.com`. Các URL dưới chỉ là mẫu, phải thay tên:

```text
https://TEN-THAT-CUA-BAN.onrender.com/api/hello
https://TEN-THAT-CUA-BAN.onrender.com/api/health
https://TEN-THAT-CUA-BAN.onrender.com/api/letters/12345
```

`/api/hello` phải trả:

```json
{"message":"Hello World"}
```

Có thể dùng URL `/api/hello` làm minh chứng chính của HW4. `/api/health` trả `{"status":"ok"}`. `/api/letters/12345` trả bó số 195 cùng thư gốc.

`render.yaml` là lựa chọn thay thế bằng Blueprint, không cần dùng nếu đã tạo thủ công. Không tạo thêm service trùng chỉ để dùng file này.

## 3. Deploy frontend React lên Vercel

Vercel → Add New → Project → Import cùng repository GitHub:

| Trường | Giá trị |
|---|---|
| Framework Preset | Vite |
| Root Directory | `frontend` |
| Install Command | `npm ci` |
| Build Command | `npm run build` |
| Output Directory | `dist` |

Thêm Environment Variable trước khi Deploy:

```text
VITE_API_URL=https://TEN-THAT-CUA-BAN.onrender.com
```

Đây là URL gốc backend, không thêm `/api` hoặc `/api/hello`. Chọn scope Production (và Preview nếu cần). Vite đưa biến này vào lúc build; đổi giá trị phải redeploy frontend. Xem [Vite trên Vercel](https://vercel.com/docs/frameworks/frontend/vite).

Sau khi deploy thành công, lấy domain Production thật, ví dụ `https://TEN-GAME.vercel.app`.

## 4. Kết nối hai bên bằng CORS

Quay lại Render → backend → Environment. Sửa:

```text
FRONTEND_ORIGINS=https://TEN-GAME.vercel.app
```

Không thêm dấu `/` cuối URL. Nếu có nhiều domain cần dùng, phân cách bằng dấu phẩy, ví dụ `https://TEN-GAME.vercel.app,http://localhost:5175`. Dùng domain Production; URL preview ngẫu nhiên phải được thêm riêng nếu muốn thử trên preview. Save và để backend redeploy.

Mở frontend → Bắt đầu → trả lời 5 câu → chọn bình và góc hoa → mở thư. Kiểm tra DevTools → Network thấy `/api/letters/.....` gọi đúng domain Render, status 200. Không cần nhập câu trả lời cá nhân khi kiểm thử: chọn mẫu bất kỳ.

## 5. Nếu muốn đặt cả frontend trên Render

HW4 chỉ quy định backend trên Render. Để game cũng ở Render, tạo **New → Static Site** từ cùng repo; Root Directory `frontend`, Build Command `npm ci && npm run build`, Publish Directory `dist`. Đặt `VITE_API_URL` như trên. Sau deploy, dùng domain của Static Site trong `FRONTEND_ORIGINS` của backend. Không dùng Static Site để chạy backend Express. Phương án này không đáp ứng riêng yêu cầu Vercel của HW3 nếu bạn nộp cả hai bài.

## 6. Kiểm tra trước khi nộp

- Link Render `/api/hello` mở công khai và hiển thị đúng JSON Hello World.
- Repository có code `import express from 'express'` và route Hello World trong `backend/src/app.js`.
- Ảnh chụp endpoint trên trình duyệt có URL Render; ảnh Render báo deploy Live.
- Nếu nộp game kèm theo: frontend mở được, tương tác bình thường và mở được thư từ API.
- Đây là gợi ý minh chứng, không phải tiêu chí bổ sung tự nhận là của giảng viên.

## Xử lý lỗi thường gặp

- `package.json` không tìm thấy: Root Directory chưa đúng; xem repo có bọc thêm thư mục `my-bouquet-hw4` không.
- `npm ci` báo thiếu lock: upload `package-lock.json` ở đúng backend/frontend.
- Backend không bind port: Start Command phải `npm start`, Root Directory `backend`.
- Trang Hello World chạy nhưng thư lỗi CORS: `FRONTEND_ORIGINS` phải trùng chính xác origin frontend, không có đường dẫn hay dấu `/` cuối.
- Request chạy vào Vercel thay vì Render: thiếu/sai `VITE_API_URL`; sửa trên Vercel và redeploy.
- Mở thư lâu ở lần đầu: một số gói Render có chế độ ngủ khi không hoạt động; chờ máy chủ sẵn sàng và dùng nút thử lại trong game. Xem [giới hạn dịch vụ miễn phí](https://render.com/docs/free).
- Sang domain mới thấy game mới: LocalStorage thuộc từng origin, đây là hành vi dự kiến.

## Chỉ khi muốn kiểm tra trên máy trước deploy

Node.js 22+. Terminal thứ nhất:

```sh
cd backend
npm ci
npm start
```

Terminal thứ hai tại gốc project:

```sh
cd frontend
npm ci
npm run dev
```

Mở http://127.0.0.1:5175. Khi phát triển không cần tạo `.env`: Vite proxy `/api` tới backend cổng 3001. `.env.example` chỉ để tham khảo; backend đọc biến môi trường hệ điều hành/Render. Nếu muốn dùng file `.env` khi chạy backend, dùng `node --env-file=.env src/server.js`.

Kiểm thử: `npm test` trong backend, `npm test` rồi `npm run build` trong frontend. Bài kiểm tra frontend đối chiếu dữ liệu trong thư mục backend cạnh nó, nên chạy từ bản giải nén đầy đủ. Chạy build để đưa lên host phải cấu hình `VITE_API_URL`; không upload bản dist build thiếu URL.
